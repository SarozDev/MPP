package lesson5.labsolns.prob3.callback.control;

public interface Callback {
	void performAction();
}
